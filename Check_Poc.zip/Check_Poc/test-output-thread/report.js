$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "b1fc7c2d-a194-4a8f-b41d-881168fcf7c5",
    "feature": "Selenium Test Task",
    "scenario": "To verify the Check24 functionality",
    "start": 1647219559359,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1647219568735,
    "className": "failed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});